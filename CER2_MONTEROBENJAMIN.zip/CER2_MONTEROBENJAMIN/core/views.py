from django.shortcuts import render
from .models import Categoria, LugarPatrimonial
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.shortcuts import get_object_or_404, redirect
from .forms import LugarPatrimonialForm

def home(request):
    #Pagina Principal
    return render(request, 'core/home.html')

def catalogo_lugares(request):
    #catalogo
    lugares = LugarPatrimonial.objects.all()
    categorias = Categoria.objects.all()

    context = {
        'lugares' : lugares,
        'categorias' : categorias
    }

    return render(request, 'core/catalogo.html', context)

@login_required
def gestionar_lugares(request):
    lugares = LugarPatrimonial.objects.all()

    context = {
        'lugares': lugares,
    }

    return render(request, 'core/gestion.html', context)

@login_required
def crear_lugar(request):
    if request.method == 'POST':
        form = LugarPatrimonialForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('gestion')
    else:
        form = LugarPatrimonialForm()

    return render(request, 'core/form_lugar.html', {'form': form, 'accion': 'Agregar'})

@login_required
def modificar_lugar(request, pk):
    lugar = get_object_or_404(LugarPatrimonial, pk=pk)
    if request.method == 'POST':
        form = LugarPatrimonialForm(request.POST, instance=lugar)
        if form.is_valid():
            form.save()
            return redirect('gestion')
    else:
        form = LugarPatrimonialForm(instance=lugar)

    return render(request, 'core/form_lugar.html', {'form': form, 'accion': 'Modificar'})

class CustomLoginView(LoginView):
    template_name = 'core/login.html'