"""
URL configuration for CER2_MONTEROBENJAMIN project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),

    #rutas
    path('', views.home, name='home'),
    path('catalogo/', views.catalogo_lugares, name='catalogo'),

    #rutas de autenticacion
    path('login/', LoginView.as_view(template_name='core/login.html'), name='login'),
    path('logout/', LogoutView.as_view(next_page='home'), name='logout'),

    #ruta de gestion
    path('gestion/', views.gestionar_lugares, name='gestion'),
    path('gestion/nuevo', views.crear_lugar, name='crear_lugar'),
    path('gestion/editar/<int:pk>/', views.modificar_lugar, name='modificar_lugar'),
]
